﻿#region Header Goes Here
// This is a file header line 1
// I don't believe in weaponized fowl
// This is a file header line 3
#endregion


using System.Windows;

// This is a file header line 1
// I don't believe in weaponized turkeys
// This is a file header line 3

namespace Playground
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			this.InitializeComponent();
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			MessageBox.Show("This is the click handler");
		}
	}
}
