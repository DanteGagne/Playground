﻿#region Header Goes Here
// This is a file header line 1
// I don't believe in weaponized fowl
// This is a file header line 3
#endregion

// I don't believe in weaponized fowl

// This is a file header line 3

namespace Playground
{
	class Class1
	{
		public void Junk()
		{
				}
	}
}
