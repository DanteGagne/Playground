﻿#region Header Goes Here
// This is a file header line 1
// I don't believe in weaponized fowl
// This is a file header line 3
#endregion

using System.Windows;

namespace Playground
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}
}
